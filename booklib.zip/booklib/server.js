const express = require('express');
const app = express();

app.use(express.urlencoded({extended: true}));
app.use(express.json());

const methodOverride = require('method-override');
app.use(methodOverride('_method'));

app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/web'));

const MongoClient = require('mongodb').MongoClient;

let bookLibDB;
let DBURL = 'mongodb+srv://admin:qwer1234@cluster0.mikzh.mongodb.net/bookLibDB?retryWrites=true&w=majority';

MongoClient.connect(DBURL, (err, result)=>{
  if(err) return console.log("Database connect Fail!");

  bookLibDB = result.db('bookLibDB');

  app.listen(8080, ()=>{
    console.log('port : 8080 open & Database connect Success!');
  });
});

app.get('/', (req, res)=>{
  bookLibDB.collection('bookLib').find().sort({_id:-1}).limit(3).toArray((err, result)=>{
    if(err) return console.log('book search fail !!!');
    res.render('index.ejs', {bookData:result});
  });
});

app.get('/bookList', (req, res)=>{
  bookLibDB.collection('bookLib').find().toArray((err, result)=>{
    if(err) return console.log('book search fail !!!');
    res.render('bookList.ejs', {bookData:result});
  });
});

app.get('/bookAdd', (req, res)=>{
  res.render('bookAdd.ejs', {});
});

app.post('/addAction', (req, res)=>{
  let bookTitle = req.body.title;
  let bookPublish = req.body.publish;
  let bookPrice = req.body.price;
  
  bookLibDB.collection('bookCount').findOne({diversity:"diversity"}, (err, result)=>{
    if(err) return console.log('책 종류의 수 검색실패!');
    let totalCount = result.totalCount;

    bookLibDB.collection('bookLib').insertOne({_id:totalCount+1, title:bookTitle, publish:bookPublish, price:Number(bookPrice)},(err, result)=>{
      if(err) return console.log('책 추가 문제 발생!')
      console.log('책 추가!');

      bookLibDB.collection('bookCount').updateOne({diversity:"diversity"},{$inc:{totalCount:1}},(err,result)=>{
        if(err) return console.log('책 종류의 수 변경 발생 !')
        res.redirect('/bookList');
      });
    });
  });
});

app.delete('/bookDelete', (req, res)=>{
  bookLibDB.collection('bookLib').deleteOne({_id:Number(req.body._id)}, (err, result)=>{
    if(err) return console.log('삭제 실패!');
    res.status(200);
  });
});

app.get('/bookView/:id', (req, res)=>{
  bookLibDB.collection('bookLib').findOne({_id:Number(req.params.id)}, (err, result)=>{
    if(err) return console.log('해당 책에 접근 불가!');
    res.render('bookView.ejs', {bookData: result});
  });
});

